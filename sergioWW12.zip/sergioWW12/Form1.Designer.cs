﻿namespace sergioweek12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textname = new System.Windows.Forms.TextBox();
            this.textteamnumber = new System.Windows.Forms.TextBox();
            this.textposition = new System.Windows.Forms.TextBox();
            this.textheight = new System.Windows.Forms.TextBox();
            this.textweight = new System.Windows.Forms.TextBox();
            this.comnationality = new System.Windows.Forms.ComboBox();
            this.comteamname = new System.Windows.Forms.ComboBox();
            this.name = new System.Windows.Forms.Label();
            this.teamnumber = new System.Windows.Forms.Label();
            this.position = new System.Windows.Forms.Label();
            this.national = new System.Windows.Forms.Label();
            this.weight = new System.Windows.Forms.Label();
            this.height = new System.Windows.Forms.Label();
            this.teamname = new System.Windows.Forms.Label();
            this.birthdate = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Addplayer = new System.Windows.Forms.Button();
            this.playerid = new System.Windows.Forms.Label();
            this.textpalyerid = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dateTimebirthdate = new System.Windows.Forms.DateTimePicker();
            this.playerr = new System.Windows.Forms.Label();
            this.teamid = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.delateplayer = new System.Windows.Forms.Button();
            this.manager = new System.Windows.Forms.Label();
            this.buttonaddmanager = new System.Windows.Forms.Button();
            this.teamname2 = new System.Windows.Forms.Label();
            this.comteam = new System.Windows.Forms.ComboBox();
            this.blabla = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addPlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(111, 57);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(100, 20);
            this.textname.TabIndex = 0;
            this.textname.Visible = false;
            // 
            // textteamnumber
            // 
            this.textteamnumber.Location = new System.Drawing.Point(111, 89);
            this.textteamnumber.Name = "textteamnumber";
            this.textteamnumber.Size = new System.Drawing.Size(100, 20);
            this.textteamnumber.TabIndex = 1;
            this.textteamnumber.Visible = false;
            // 
            // textposition
            // 
            this.textposition.Location = new System.Drawing.Point(111, 162);
            this.textposition.Name = "textposition";
            this.textposition.Size = new System.Drawing.Size(100, 20);
            this.textposition.TabIndex = 2;
            this.textposition.Visible = false;
            // 
            // textheight
            // 
            this.textheight.Location = new System.Drawing.Point(111, 202);
            this.textheight.Name = "textheight";
            this.textheight.Size = new System.Drawing.Size(100, 20);
            this.textheight.TabIndex = 3;
            this.textheight.Visible = false;
            this.textheight.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textweight
            // 
            this.textweight.Location = new System.Drawing.Point(111, 240);
            this.textweight.Name = "textweight";
            this.textweight.Size = new System.Drawing.Size(100, 20);
            this.textweight.TabIndex = 4;
            this.textweight.Visible = false;
            // 
            // comnationality
            // 
            this.comnationality.FormattingEnabled = true;
            this.comnationality.Location = new System.Drawing.Point(111, 127);
            this.comnationality.Name = "comnationality";
            this.comnationality.Size = new System.Drawing.Size(121, 21);
            this.comnationality.TabIndex = 5;
            this.comnationality.Visible = false;
            // 
            // comteamname
            // 
            this.comteamname.FormattingEnabled = true;
            this.comteamname.Location = new System.Drawing.Point(111, 321);
            this.comteamname.Name = "comteamname";
            this.comteamname.Size = new System.Drawing.Size(121, 21);
            this.comteamname.TabIndex = 7;
            this.comteamname.Visible = false;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(16, 64);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(35, 13);
            this.name.TabIndex = 8;
            this.name.Text = "Name";
            this.name.Visible = false;
            // 
            // teamnumber
            // 
            this.teamnumber.AutoSize = true;
            this.teamnumber.Location = new System.Drawing.Point(13, 89);
            this.teamnumber.Name = "teamnumber";
            this.teamnumber.Size = new System.Drawing.Size(77, 13);
            this.teamnumber.TabIndex = 9;
            this.teamnumber.Text = "Team_Number";
            this.teamnumber.Visible = false;
            // 
            // position
            // 
            this.position.AutoSize = true;
            this.position.Location = new System.Drawing.Point(13, 167);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(44, 13);
            this.position.TabIndex = 11;
            this.position.Text = "Position";
            this.position.Visible = false;
            this.position.Click += new System.EventHandler(this.label3_Click);
            // 
            // national
            // 
            this.national.AutoSize = true;
            this.national.Location = new System.Drawing.Point(13, 130);
            this.national.Name = "national";
            this.national.Size = new System.Drawing.Size(56, 13);
            this.national.TabIndex = 10;
            this.national.Text = "Nationality";
            this.national.Visible = false;
            // 
            // weight
            // 
            this.weight.AutoSize = true;
            this.weight.Location = new System.Drawing.Point(13, 239);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(41, 13);
            this.weight.TabIndex = 13;
            this.weight.Text = "Weight";
            this.weight.Visible = false;
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(13, 202);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(38, 13);
            this.height.TabIndex = 12;
            this.height.Text = "Height";
            this.height.Visible = false;
            // 
            // teamname
            // 
            this.teamname.AutoSize = true;
            this.teamname.Location = new System.Drawing.Point(13, 321);
            this.teamname.Name = "teamname";
            this.teamname.Size = new System.Drawing.Size(65, 13);
            this.teamname.TabIndex = 15;
            this.teamname.Text = "Team Name";
            this.teamname.Visible = false;
            // 
            // birthdate
            // 
            this.birthdate.AutoSize = true;
            this.birthdate.Location = new System.Drawing.Point(13, 284);
            this.birthdate.Name = "birthdate";
            this.birthdate.Size = new System.Drawing.Size(49, 13);
            this.birthdate.TabIndex = 14;
            this.birthdate.Text = "Birthdate";
            this.birthdate.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(355, 167);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.Visible = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(355, 368);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 18;
            this.dataGridView2.Visible = false;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView2_CellMouseClick);
            // 
            // Addplayer
            // 
            this.Addplayer.Location = new System.Drawing.Point(111, 345);
            this.Addplayer.Name = "Addplayer";
            this.Addplayer.Size = new System.Drawing.Size(75, 23);
            this.Addplayer.TabIndex = 20;
            this.Addplayer.Text = "Add player ";
            this.Addplayer.UseVisualStyleBackColor = true;
            this.Addplayer.Visible = false;
            this.Addplayer.Click += new System.EventHandler(this.button1_Click);
            // 
            // playerid
            // 
            this.playerid.AutoSize = true;
            this.playerid.Location = new System.Drawing.Point(16, 39);
            this.playerid.Name = "playerid";
            this.playerid.Size = new System.Drawing.Size(46, 13);
            this.playerid.TabIndex = 21;
            this.playerid.Text = "player id";
            this.playerid.Visible = false;
            // 
            // textpalyerid
            // 
            this.textpalyerid.Location = new System.Drawing.Point(111, 36);
            this.textpalyerid.Name = "textpalyerid";
            this.textpalyerid.Size = new System.Drawing.Size(100, 20);
            this.textpalyerid.TabIndex = 22;
            this.textpalyerid.Visible = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(12, 397);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(297, 203);
            this.dataGridView3.TabIndex = 23;
            this.dataGridView3.Visible = false;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // dateTimebirthdate
            // 
            this.dateTimebirthdate.Location = new System.Drawing.Point(111, 284);
            this.dateTimebirthdate.Name = "dateTimebirthdate";
            this.dateTimebirthdate.Size = new System.Drawing.Size(200, 20);
            this.dateTimebirthdate.TabIndex = 25;
            this.dateTimebirthdate.Visible = false;
            // 
            // playerr
            // 
            this.playerr.AutoSize = true;
            this.playerr.Location = new System.Drawing.Point(666, 117);
            this.playerr.Name = "playerr";
            this.playerr.Size = new System.Drawing.Size(46, 13);
            this.playerr.TabIndex = 26;
            this.playerr.Text = "player id";
            this.playerr.Visible = false;
            // 
            // teamid
            // 
            this.teamid.AutoSize = true;
            this.teamid.Location = new System.Drawing.Point(666, 69);
            this.teamid.Name = "teamid";
            this.teamid.Size = new System.Drawing.Size(41, 13);
            this.teamid.TabIndex = 28;
            this.teamid.Text = "team id";
            this.teamid.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(723, 61);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 29;
            this.comboBox2.Visible = false;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            this.comboBox2.SelectionChangeCommitted += new System.EventHandler(this.comboBox2_SelectionChangeCommitted);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(108, 448);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 13);
            this.label15.TabIndex = 30;
            // 
            // delateplayer
            // 
            this.delateplayer.Location = new System.Drawing.Point(744, 117);
            this.delateplayer.Name = "delateplayer";
            this.delateplayer.Size = new System.Drawing.Size(75, 23);
            this.delateplayer.TabIndex = 31;
            this.delateplayer.Text = "delete player ";
            this.delateplayer.UseVisualStyleBackColor = true;
            this.delateplayer.Visible = false;
            this.delateplayer.Click += new System.EventHandler(this.button2_Click);
            // 
            // manager
            // 
            this.manager.AutoSize = true;
            this.manager.Location = new System.Drawing.Point(340, 110);
            this.manager.Name = "manager";
            this.manager.Size = new System.Drawing.Size(77, 13);
            this.manager.TabIndex = 34;
            this.manager.Text = "manager name";
            this.manager.Visible = false;
            // 
            // buttonaddmanager
            // 
            this.buttonaddmanager.Location = new System.Drawing.Point(355, 138);
            this.buttonaddmanager.Name = "buttonaddmanager";
            this.buttonaddmanager.Size = new System.Drawing.Size(121, 23);
            this.buttonaddmanager.TabIndex = 36;
            this.buttonaddmanager.Text = "Add manager ";
            this.buttonaddmanager.UseVisualStyleBackColor = true;
            this.buttonaddmanager.Visible = false;
            this.buttonaddmanager.Click += new System.EventHandler(this.button3_Click);
            // 
            // teamname2
            // 
            this.teamname2.AutoSize = true;
            this.teamname2.Location = new System.Drawing.Point(340, 77);
            this.teamname2.Name = "teamname2";
            this.teamname2.Size = new System.Drawing.Size(65, 13);
            this.teamname2.TabIndex = 37;
            this.teamname2.Text = "Team Name";
            this.teamname2.Visible = false;
            // 
            // comteam
            // 
            this.comteam.FormattingEnabled = true;
            this.comteam.Location = new System.Drawing.Point(428, 77);
            this.comteam.Name = "comteam";
            this.comteam.Size = new System.Drawing.Size(121, 21);
            this.comteam.TabIndex = 38;
            this.comteam.Visible = false;
            this.comteam.SelectionChangeCommitted += new System.EventHandler(this.comboBox5_SelectionChangeCommitted);
            // 
            // blabla
            // 
            this.blabla.AutoSize = true;
            this.blabla.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blabla.Location = new System.Drawing.Point(424, 110);
            this.blabla.Name = "blabla";
            this.blabla.Size = new System.Drawing.Size(144, 20);
            this.blabla.TabIndex = 39;
            this.blabla.Text = "_______________";
            this.blabla.Visible = false;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(631, 202);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(297, 203);
            this.dataGridView4.TabIndex = 40;
            this.dataGridView4.Visible = false;
            this.dataGridView4.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_CellMouseClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPlayerToolStripMenuItem,
            this.addManagerToolStripMenuItem,
            this.removeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1284, 24);
            this.menuStrip1.TabIndex = 42;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addPlayerToolStripMenuItem
            // 
            this.addPlayerToolStripMenuItem.Name = "addPlayerToolStripMenuItem";
            this.addPlayerToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.addPlayerToolStripMenuItem.Text = "Add Player ";
            this.addPlayerToolStripMenuItem.Click += new System.EventHandler(this.addPlayerToolStripMenuItem_Click);
            // 
            // addManagerToolStripMenuItem
            // 
            this.addManagerToolStripMenuItem.Name = "addManagerToolStripMenuItem";
            this.addManagerToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.addManagerToolStripMenuItem.Text = "Add manager ";
            this.addManagerToolStripMenuItem.Click += new System.EventHandler(this.addManagerToolStripMenuItem_Click);
            // 
            // removeToolStripMenuItem
            // 
            this.removeToolStripMenuItem.Name = "removeToolStripMenuItem";
            this.removeToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.removeToolStripMenuItem.Text = "Remove";
            this.removeToolStripMenuItem.Click += new System.EventHandler(this.removeToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 612);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.blabla);
            this.Controls.Add(this.comteam);
            this.Controls.Add(this.teamname2);
            this.Controls.Add(this.buttonaddmanager);
            this.Controls.Add(this.manager);
            this.Controls.Add(this.delateplayer);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.teamid);
            this.Controls.Add(this.playerr);
            this.Controls.Add(this.dateTimebirthdate);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.textpalyerid);
            this.Controls.Add(this.playerid);
            this.Controls.Add(this.Addplayer);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.teamname);
            this.Controls.Add(this.birthdate);
            this.Controls.Add(this.weight);
            this.Controls.Add(this.height);
            this.Controls.Add(this.position);
            this.Controls.Add(this.national);
            this.Controls.Add(this.teamnumber);
            this.Controls.Add(this.name);
            this.Controls.Add(this.comteamname);
            this.Controls.Add(this.comnationality);
            this.Controls.Add(this.textweight);
            this.Controls.Add(this.textheight);
            this.Controls.Add(this.textposition);
            this.Controls.Add(this.textteamnumber);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textteamnumber;
        private System.Windows.Forms.TextBox textposition;
        private System.Windows.Forms.TextBox textheight;
        private System.Windows.Forms.TextBox textweight;
        private System.Windows.Forms.ComboBox comnationality;
        private System.Windows.Forms.ComboBox comteamname;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label teamnumber;
        private System.Windows.Forms.Label position;
        private System.Windows.Forms.Label national;
        private System.Windows.Forms.Label weight;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.Label teamname;
        private System.Windows.Forms.Label birthdate;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button Addplayer;
        private System.Windows.Forms.Label playerid;
        private System.Windows.Forms.TextBox textpalyerid;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DateTimePicker dateTimebirthdate;
        private System.Windows.Forms.Label playerr;
        private System.Windows.Forms.Label teamid;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button delateplayer;
        private System.Windows.Forms.Label manager;
        private System.Windows.Forms.Button buttonaddmanager;
        private System.Windows.Forms.Label teamname2;
        private System.Windows.Forms.ComboBox comteam;
        private System.Windows.Forms.Label blabla;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addPlayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeToolStripMenuItem;
    }
}

